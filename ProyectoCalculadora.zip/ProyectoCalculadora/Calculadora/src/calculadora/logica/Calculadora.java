
package calculadora.logica;


public class Calculadora {
    int num1;
    int num2;
    int res;
    
    public void setNum1(int num1){
    this.num1 = num1;
    }
    public void setNum2(int num2){
    this.num2 = num2;
    }
    public int getRes(){
        return res;
    }
    public void sumar(){
        res = num1 + num2;
    }
 public void restar(){
        res = num1 - num2;      
    }
  public void multiplicar(){
        res = num1 * num2;
    }
   public void dividir(){
        res = num1 / num2;
    }
}
