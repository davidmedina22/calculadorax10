package calculadora;

import java.util.Scanner;
import calculadora.logica.Calculadora;

public class Principal {


    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Calculadora cal = new Calculadora();
        System.out.println("Ingrese el primer número");
        cal.setNum1(sc.nextInt());
        System.out.println("Ingrese el segundo número");
        cal.setNum2(sc.nextInt());
        
        cal.sumar();
        
        System.out.println("La suma es: "+cal.getRes());
    }
    
}
